#include <gtk/gtk.h>


gboolean
update_config                          (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_ch1_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch2_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch3_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch4_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch5_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch6_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch7_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch8_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch9_chk_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch10_chk_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch11_chk_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch12_chk_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch13_chk_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch14_chk_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch15_chk_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ch16_chk_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
