#ifndef _MAIN_H_
#define _MAIN_H_

void gui_update(void);

#endif /* _MAIN_H_ */
