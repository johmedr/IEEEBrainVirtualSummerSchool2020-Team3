#include <gtk/gtk.h>


gboolean
dlg_delete                             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);
