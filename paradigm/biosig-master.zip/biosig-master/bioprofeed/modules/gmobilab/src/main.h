#ifndef _MAIN_H_
#define _MAIN_H_

void c_update(void);
unsigned char c_is_active(int);

#endif /* _MAIN_H_ */
