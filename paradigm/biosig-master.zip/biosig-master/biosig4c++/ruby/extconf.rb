require 'mkmf'
create_makefile('biosig')

